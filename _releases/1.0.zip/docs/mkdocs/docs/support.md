# Support

## Website

For product-specific support, please comment directly in the relevant sections of our website. For general inquiries, visit [bugfish.eu](https://www.bugfish.eu).

## Forum

For faster assistance, post in our forum at [bugfish.eu/forum](https://www.bugfish.eu/forum). Alternatively, email us at [requests@bugfish.eu](mailto:requests@bugfish.eu).

## GitHub

For technical issues or feature requests, open an issue in our GitHub repository via the Navigation/Header Link on our site.